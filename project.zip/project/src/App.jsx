import VerticalSlider from './ScrollUpAndDown'

const App = () => {
  return (
    <div>
      <VerticalSlider />
    </div>
  )
}

export default App
